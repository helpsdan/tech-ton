const app = require("./index");

app.listen(3000, () => {
  console.log("Server is now running!");
});
