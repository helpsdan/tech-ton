const UsersModel = require("../model/users.model")

exports.createUser = async (req, res) => {
    try {
        const createUser = await UsersModel.createUser(req, res);
        res.status(201).json(createUser);
    } catch (err) {
        res.status(400).json({ error: 'Could not create user' });
    }
}

exports.getUser = async (req, res) => {
    try {
        const getUser = await UsersModel.getUserById(req, res);
        res.status(200).json(getUser)
    } catch (error) {
        res.status(400).json({ error: 'Could not get user' });
    }
}