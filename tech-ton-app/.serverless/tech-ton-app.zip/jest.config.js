module.exports = {
    testEnvironment: "node"
};